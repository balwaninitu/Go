Seller functions, talks to apiclient.go, server.go and temaplates 
