Login, logout, signup ..
maintains sessions, cookies, talks to db to signup and login buyer or seller
communicates with buyer and seller functions to pass info about login
