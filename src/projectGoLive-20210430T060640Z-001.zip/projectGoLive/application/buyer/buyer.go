Handles buyer functions - talks to templates and apiclient
gets login info from server.go
