package main

import (
	"projectGoLive/start"

	_ "github.com/go-sql-driver/mysql"
)

func main() {

	start.StartApplication()
}
